<?

$result['formdetails'] = 'id="form"';
$result['text'] = 'Add';
	
header('Content-type: text/json; charset=utf-8');
echo (json_encode($result));


?>